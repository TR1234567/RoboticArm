#!/usr/bin/env python
# coding: utf-8

# In[84]:


import cv2
import matplotlib.pyplot as plt
import numpy as np


# In[122]:


image = cv2.imread('Untitled Folder 3/WIN_20191223_16_17_25_Pro.jpg',cv2.IMREAD_UNCHANGED)
img = image[0:1000, 160:450]
plt.imshow(img)
b,g,r = cv2.split(img)


# In[123]:


clahe = cv2.createCLAHE(clipLimit=2.0, tileGridSize=(8,8))


# In[124]:


kernel = np.ones((5,5),np.float32)/25
dst = cv2.filter2D(r,-1,kernel)
cl1 = clahe.apply(dst)


# In[125]:


ret,thresh1 = cv2.threshold(cl1,200,255,cv2.THRESH_BINARY)


# In[177]:


r1 = cv2.morphologyEx(thresh1, cv2.MORPH_OPEN, cv2.getStructuringElement(cv2.MORPH_ELLIPSE,(5,5)), iterations = 1)
R1 = cv2.morphologyEx(r1, cv2.MORPH_CLOSE, cv2.getStructuringElement(cv2.MORPH_ELLIPSE,(5,5)), iterations = 1)
r2 = cv2.morphologyEx(R1, cv2.MORPH_OPEN, cv2.getStructuringElement(cv2.MORPH_ELLIPSE,(11,11)), iterations = 1)
R2 = cv2.morphologyEx(r2, cv2.MORPH_CLOSE, cv2.getStructuringElement(cv2.MORPH_ELLIPSE,(11,11)), iterations = 1)
r3 = cv2.morphologyEx(R2, cv2.MORPH_OPEN, cv2.getStructuringElement(cv2.MORPH_ELLIPSE,(23,23)), iterations = 1)
R3 = cv2.morphologyEx(r3, cv2.MORPH_CLOSE, cv2.getStructuringElement(cv2.MORPH_ELLIPSE,(23,23)), iterations = 1)	
f4 = cv2.subtract(R3,thresh1)
f5 = clahe.apply(f4)	


# In[178]:


__, contours, hierarchy = cv2.findContours(R2, cv2.RETR_TREE, cv2.CHAIN_APPROX_NONE)


# In[179]:


con_img = img.copy()


# In[180]:


v = cv2.drawContours(con_img,contours, -1, (255,255,255), 3)


# In[181]:


plt.imshow(v,cmap='gray')


# In[176]:


len(contours)


# In[ ]:





# In[ ]:




